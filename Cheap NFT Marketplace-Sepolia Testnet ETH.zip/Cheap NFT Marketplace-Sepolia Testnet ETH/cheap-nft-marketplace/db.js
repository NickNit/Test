const nfts = [];

module.exports = nfts;
